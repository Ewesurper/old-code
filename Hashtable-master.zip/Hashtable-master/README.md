
# Hashtable
Hashtable helps in organizing credentials and accounts compromised during an engagment. These scripts are still in developement and are subject to change.

## How to use for cobalt strike exports
```bash
python Hashtable_CobaltStrike.py -pf /path/to/hashcat.potfile -hf /path/to/cobaltstrike_credential_export
```

## How to use for hashdump exports
```bash
python Hashtable_Hashdump.py -pf /path/to/hashcat.potfile -hf /path/to/hashdump_export
```
